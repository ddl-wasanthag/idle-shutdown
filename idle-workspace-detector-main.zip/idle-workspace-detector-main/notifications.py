import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
import os


# Create the email alerting the user that the workspace has been stopped.
def format_stopped_email(
    config, workspace_name, project_name, workspace_owner_username
):
    workspace_message = 'Workspace "{}" - https://{}/{}/{}'.format(
        workspace_name,
        config["domino_domain"],
        workspace_owner_username,
        project_name,
    )

    email_text = Path("stopped_email.txt").read_text()

    email_html = Path("stopped_email.html").read_text()

    email_html = email_html.replace(
        "$WORKSPACE_MESSAGE", "".join(workspace_message)
    ).replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))

    email_text = email_text.replace(
        "$WORKSPACE_MESSAGE", "".join(workspace_message)
    ).replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))

    return dict(html=email_html, text=email_text)


# Creates the email warning the user that the workspace is idle for more
# than 4 hours.
def format_warning_email(
    config, workspace_name, project_name, workspace_owner_username
):
    workspace_message = 'Workspace "{}" - https://{}/{}/{}'.format(
        workspace_name,
        config["domino_domain"],
        workspace_owner_username,
        project_name,
    )

    email_text = Path("warning_email.txt").read_text()

    email_html = Path("warning_email.html").read_text()

    email_html = (
        email_html.replace("$WORKSPACE_MESSAGE", "".join(workspace_message))
        .replace("$WARNING_INTERVAL", str(config["idle"]["warning_interval_hours"]))
        .replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))
    )

    email_text = (
        email_text.replace("$WORKSPACE_MESSAGE", "".join(workspace_message))
        .replace("$WARNING_INTERVAL", str(config["idle"]["warning_interval_hours"]))
        .replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))
    )

    return dict(html=email_html, text=email_text)


# Sends an email to the to address with the contents built from the format
# functions.
def send_email(config, to, contents, subject):
    # Create message container - the correct MIME type is
    # multipart/alternative.
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = config["notify"]["from_email"]
    msg["To"] = to
    # msg['Cc'] = ""

    # Record the MIME types of both parts - text/plain and text/html.
    part1 = MIMEText(contents["text"], "plain")
    part2 = MIMEText(contents["html"], "html")

    # Attach parts into message container.
    # According to RFC 2046, the last part of a multipart message, in this case
    # the HTML message, is best and preferred.
    msg.attach(part1)
    msg.attach(part2)

    # Send the message via local SMTP server.
    s = smtplib.SMTP(config["notify"]["smtp_host"], config["notify"]["smtp_port"])
    s.ehlo()
    s.starttls()
    s.ehlo()
    smtp_user = os.getenv("SMTP_USERNAME", None)
    smtp_password = os.getenv("SMTP_PASSWORD", None)
    if smtp_user and smtp_password:
        s.login(smtp_user, smtp_password)
    # sendmail function takes 3 arguments: sender's address, recipient's
    # address and message to send - here it is sent as one string.
    # s.sendmail(msg['From'],  msg["To"].split(",") + msg["Cc"].split(","),
    # msg.as_string())
    s.sendmail(msg["From"], msg["To"], msg.as_string())
    s.quit()
