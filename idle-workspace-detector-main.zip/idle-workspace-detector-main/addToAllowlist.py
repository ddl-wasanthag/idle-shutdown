import csv
import sys
import os
from pymongo import MongoClient
from pathlib import Path
import pandas as pd
import yaml
from bson.objectid import ObjectId
import logging

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

DATASET_PATH = "/domino/datasets/local/" + os.environ["DOMINO_PROJECT_NAME"]
ALLOW_LIST_PATH = f"{DATASET_PATH}/data/allowlist.csv"


# Create the allowlist csv if it does not exist.
def init_allow_csv():
    with open(ALLOW_LIST_PATH, "w") as csvfile:
        writer = csv.writer(csvfile, delimiter=",")
        writer.writerow(["UserId", "ProjectId"])


if not Path(f"{DATASET_PATH}/data").is_dir():
    os.mkdir(f"{DATASET_PATH}/data")

if not Path(ALLOW_LIST_PATH).is_file():
    init_allow_csv()

# Collect username and project name from arguments
username = "integration-test"  # sys.argv[1]

project_name = "quick-start"  # sys.argv[2]

config = None
with open("config.yaml", "r") as file:
    config = yaml.safe_load(file)

# Mongo Variables
user = os.environ["MONGODB_USERNAME"]
password = os.environ["MONGODB_PASSWORD"]
platform_namespace = config["domino_platform_namespace"]

# Create the MongoDB Client
client = MongoClient(
    "mongodb://mongodb-replicaset.{}.svc.cluster.local:27017".format(
        platform_namespace
    ),
    username=user,
    password=password,
    authSource="domino",
    authMechanism="SCRAM-SHA-1",
)

db = client["domino"]

# Get the project and user IDs

user = pd.DataFrame.from_records(list(db.users.find({"loginId.id": username})))
user_id = user["_id"][0]
project = pd.DataFrame.from_records(
    list(db.projects.find({"name": project_name, "ownerId": ObjectId(user_id)}))
)
project_id = project["_id"][0]

# Add project ID and user ID to allowlist if it is not already there.
allowlist = pd.read_csv(ALLOW_LIST_PATH)

if (
    len(
        allowlist.loc[
            (allowlist["ProjectId"] == str(project_id))
            & (allowlist["UserId"] == str(user_id))
        ]
    )
    > 0
):
    logger.info(
        f"The pair ProjectId: {project_id} and UserId: {user_id} already exist in the allowlist."
    )
    exit(0)

with open(ALLOW_LIST_PATH, "a") as f:
    writer = csv.writer(f)
    writer.writerow([user["_id"][0], project["_id"][0]])
