import requests
import csv
import os
from datetime import datetime
from idle_wksp_base import IdleWorkspacesBase
import logging

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)
DATASET_PATH = "/domino/datasets/local/" + os.environ["DOMINO_PROJECT_NAME"]


class IdleWorkspacesActive(IdleWorkspacesBase):
    def __init__(self, config):
        super().__init__(config)
        self.dry_run_prefix = ""

    def log_workspace_shutdown(self, workspace):
        log_file = DATASET_PATH + "/data/Workspace_Shutdown_Log.csv"
        file_exists = os.path.isfile(log_file)

        with open(log_file, mode="a", newline="") as file:
            fieldnames = [
                "WorkspaceId",
                "WorkspaceName",
                "OwnerId",
                "SessionId",
                "ProjectId",
                "Timestamp",
            ]
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            if not file_exists:
                writer.writeheader()  # file doesn't exist yet, write a header

            writer.writerow(
                {
                    "WorkspaceId": workspace["WorkspaceId"],
                    "WorkspaceName": workspace["WorkspaceName"],
                    "OwnerId": workspace["OwnerId"],
                    "SessionId": workspace["SessionId"],
                    "ProjectId": workspace["ProjectId"],
                    "Timestamp": datetime.now().isoformat(),
                }
            )

    # Shutdown a workspace using the Domino API and send an email alerting
    # the user.
    def shutdown_workspace(self, workspace):
        url = "{}/v4/workspace/project/{}/workspace/{}/stop".format(
            self.domino_api_host,
            workspace["ProjectId"],
            workspace["WorkspaceId"],
        )
        response = requests.post(url, headers=self.header)

        logger.info(
            f"Shutting down workspace with id {workspace['WorkspaceId']} inside project id {workspace['ProjectId']}"
        )

        return response.status_code == 200

    def get_recipient_email(self, user):
        return user["email"]
